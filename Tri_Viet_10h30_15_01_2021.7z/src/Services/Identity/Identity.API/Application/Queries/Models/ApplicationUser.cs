﻿using System;
using Microsoft.AspNetCore.Identity;

namespace Identity.API.Application.Queries.Models
{
    public class ApplicationUser: IdentityUser
    {
    }
}