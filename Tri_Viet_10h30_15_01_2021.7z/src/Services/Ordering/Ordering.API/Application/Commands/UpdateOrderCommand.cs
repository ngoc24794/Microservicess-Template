﻿using MediatR;

namespace Ordering.API.Application.Commands
{
    public class UpdateOrderCommand : IRequest<bool>
    {

    }
}